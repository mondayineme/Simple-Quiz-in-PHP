# secure-quiz-webapp

This project was built using html, css, js, php and mysql.

The major function of this project is listed below.

1. Allows valid users to post different question and also avoid duplicate questions.
2. Allows users to be able to partake in quiz, by simply selecting number of questions and duration of choice.
3. Create a list of results for the user.
4. Generate correction for questions that user failed during the test.

#HOW TO INSTALL

1. Download this whole project.
2. Unzip in your server root or web hosting provider root.
3. Configure the 'config.php' and set your database connection parameters.
4. In your database server create a new database named quiz.
5. import the quiz.sql file into the database.
6. Your project is ready to run.

#DONATION

If you want to donate and encourage me for this project kindly contact me via the following means.

Phone : +234 9047238648
Whatsapp : +234 9047238648
Email : fatokunfemi03@gmail.com
Facebook : web.facebook.com/femi.fatokun.165
